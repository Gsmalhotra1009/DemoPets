package com.DemoPet.appconfig;

import java.io.File;

import org.ini4j.Ini;


public class Config {
	public static String vUrl ="https://petstore.swagger.io/v2/pet";
	public static String vProjPath  = System.getProperty("user.dir");
	
	
	public Config() {
		
		}
	}
	

